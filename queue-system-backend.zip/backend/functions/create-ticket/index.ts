import { APIGatewayProxyHandlerV2 } from "aws-lambda";
import { PutCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { v4 as uuidv4 } from "uuid";
import {
  docClient,
  TABLE_COUNTERS,
  TABLE_TICKETS,
} from "../../shared/dynamodb";
import {
  calcExpiresAt,
  getCounterId,
  getDateKey,
  padTicketNumber,
} from "../../shared/dateKey";
import { buildSuccessResponse, handleError } from "../../shared/response";
import { CreateTicketResponse, TicketItem } from "../../shared/types";

// POST /tickets — 発券
// リクエストボディは不要。detail-design.md 3.1 の処理フローに対応。
export const handler: APIGatewayProxyHandlerV2 = async () => {
  try {
    const now = new Date();
    const dateKey = getDateKey(now);
    const counterId = getCounterId(now);

    // Countersアイテムに対しアトミックにissuedNumberを+1する。
    // アイテムが存在しない(=当日初めての発券)場合は、UpdateItemのUpsert動作により
    // issuedNumber=1として新規作成される。
    // 同時にcalledNumberにも0を加算しておくことで、新規作成時にcalledNumber属性を
    // 明示的に0で初期化する(未発券の日でもGetItemで両属性が揃った状態にするため)。
    const updateResult = await docClient.send(
      new UpdateCommand({
        TableName: TABLE_COUNTERS,
        Key: { counterId },
        UpdateExpression: "ADD issuedNumber :inc, calledNumber :zero",
        ExpressionAttributeValues: { ":inc": 1, ":zero": 0 },
        ReturnValues: "UPDATED_NEW",
      })
    );

    const issuedNumber = updateResult.Attributes?.issuedNumber as number;

    const ticketToken = uuidv4();
    const expiresAt = calcExpiresAt(now);

    const ticketItem: TicketItem = {
      dateKey,
      ticketNumber: padTicketNumber(issuedNumber),
      ticketToken,
      status: "issued",
      createdAt: now.toISOString(),
      expiresAt,
    };

    await docClient.send(
      new PutCommand({
        TableName: TABLE_TICKETS,
        Item: ticketItem,
      })
    );

    const responseBody: CreateTicketResponse = {
      ticketNumber: issuedNumber,
      ticketToken,
    };

    return buildSuccessResponse(201, responseBody);
  } catch (error) {
    return handleError(error);
  }
};
